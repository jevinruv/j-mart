export class ShoppingCart {
    public id: number;
    public userId: number;
    public shoppingCartProducts: [];
}