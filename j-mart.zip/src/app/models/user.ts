export class User {
    email: string;
    name: string;
    role: string;

    constructor(private password: string) { }

}