export const environment = {
  production: true,
  apiUrl: 'http://j-mart.herokuapp.com/api'
};
